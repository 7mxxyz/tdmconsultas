<?php

error_reporting(0);

$lista = $_GET['lista'];

if(file_exists('haika.txt')){
  unlink('haika.txt');
}

$urlpagarrme = 'https://sistema.consultcenter.com.br/users/login';

$headers1 = [
  'authority: sistema.consultcenter.com.br',
  'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
  'content-type: application/x-www-form-urlencoded',
  'origin: https://sistema.consultcenter.com.br',
  'referer: https://sistema.consultcenter.com.br/users/login',
  'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.43',
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlpagarrme);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'./haika.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'./haika.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '_method=POST&data%5BUsuarioLogin%5D%5Busername%5D=135899&data%5BUsuarioLogin%5D%5Bpassword%5D=consulta123');
$reprovada = curl_exec($ch);

$urlpagarrme = 'https://sistema.consultcenter.com.br/localizador_nacional/consultar/4175';

$headers1 = [
  'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
  'accept-language: pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
  'content-type: application/x-www-form-urlencoded',
  'origin: https://sistema.consultcenter.com.br',
  'referer: https://sistema.consultcenter.com.br/localizador_nacional/consultar/4175',
  'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.43',
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlpagarrme);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'./haika.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'./haika.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'nome='.$lista.'&uf=');
$reprovada = curl_exec($ch);


$dom = new DOMDocument();
$dom->loadHTML($reprovada);

$xpath = new DOMXPath($dom);

$linhasTabela = $xpath->query('//tbody/tr');

$dados = array();

foreach ($linhasTabela as $linha) {

    $celulas = $xpath->query('td', $linha);

    $cpf = trim($celulas[0]->nodeValue);
    $nome = trim($celulas[1]->nodeValue);
    $dataNascimento = trim($celulas[2]->nodeValue);

    $dados[] = array(
        'CPF' => $cpf,
        'Nome' => $nome,
        'Data de Nascimento' => $dataNascimento,
    );
}

foreach ($dados as $entrada) {
    echo "<b>🔍 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗡𝗢𝗠𝗘 🔍</b><br><br>";
    echo "CPF: " . $entrada['CPF'] . "<br>";
    echo "Nome: " . $entrada['Nome'] . "<br>";
    echo "Data de Nascimento: " . $entrada['Data de Nascimento'] . "<br>";
    echo "<br>";
}