<?php

error_reporting(0);

function getStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$lista = $_GET['nome'];

$headers = array(
    'accept: application/json, text/plain, */*',
    'accept-language: en-US,en;q=0.9',
    'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZFVzZXIiOjE0NCwiSVNfQWRtaW4iOjAsImNwZiI6IjEzNTQ4MTczNDYyIiwiZXhwIjoxNzY2Njg1NTk5LCJ0aW1lIjoxNjY2NjQyMzk5fQ.5EDkLo8JS8ntAyOmUHmtAG9XC13cqc5H9AuI0B27pu4',
    'content-type: application/json',

    "cpf" => "014.989.817-71",
    "senha" => "07filhos"
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://portal.pmerj.rj.gov.br/190/system_api/authentication");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
$retorno = curl_exec($ch);

$auth = getStr($retorno, '"token":"', '"');

$headers = array(
    'accept: application/json, text/plain, */*',
    'accept-language: en-US,en;q=0.9,pt;q=0.8',
    'authorization: Bearer '.$auth,
    'content-type: application/json',
    'origin: https://portal.pmerj.rj.gov.br',
    'referer: https://portal.pmerj.rj.gov.br/consultas/consultapessoas',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.60',
);

$post = '{"vmae":"","vnasc":"","vnome":"'.$lista.'","vpai":"","vvulgo":""}';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://portal.pmerj.rj.gov.br/190/api/IdentCivil/getPessoa');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

$retorno = curl_exec($ch);

$json = json_decode($retorno, true);

if ($json === null) {
    echo 'Erro ao decodificar JSON: ' . json_last_error_msg();
} else {
    // Acesse a matriz "dados"
    $dados = $json;

    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Api By mxxyz</title>
    </head>
    <body>
        <h1>Use com moderação pls, n esquece de ativar a VPN (By mxxyz <3)</h1>';
    echo '<div>';
    $fotosExibidas = array(); // Array para rastrear fotos exibidas

    foreach ($dados as $objeto) {
        if (isset($objeto['FotoCivil']) && !in_array($objeto['FotoCivil'], $fotosExibidas)) {
            $fotoCivil = $objeto['FotoCivil'];

            echo '<img _ngcontent-c16="" class="controle-foto-servidor ng-star-inserted" height="auto" style="width: 70px !important;" src="data:image/jpg;base64,'.$fotoCivil.'">';
        }
    }
    echo '</div>';

    echo '</body>
    </html>';
}
?>